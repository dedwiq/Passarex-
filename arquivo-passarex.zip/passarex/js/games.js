import { sfx, toast } from "./core.js";

const cv = document.getElementById("game"), x = cv.getContext("2d"), W = 640, H = 480;
cv.width = W; cv.height = H;
const ui = document.getElementById("gameUI");
let loop = null, cleanup = [];
function stop() { cancelAnimationFrame(loop); cleanup.forEach(f => f()); cleanup = []; ui.innerHTML = ""; cv.style.display = "block"; }
function on(el, ev, fn) { el.addEventListener(ev, fn); cleanup.push(() => el.removeEventListener(ev, fn)); }
function pt(e) { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) * W / r.width, y: (e.clientY - r.top) * H / r.height }; }
const best = (k, v) => { try { const o = +localStorage.getItem(k) || 0; if (v > o) localStorage.setItem(k, v); return Math.max(o, v); } catch { return v; } };

// Desenho do Passarex visto de cima/de frente
function drawPx(px, py, s = 1, flap = 0, gold = false) {
  x.save(); x.translate(px, py); x.scale(s, s);
  x.fillStyle = gold ? "#e8b923" : "#1d1a15";
  const f = Math.sin(flap) * 14;
  x.beginPath(); x.moveTo(-10, 0); x.quadraticCurveTo(-40, -20 - f, -60, -5 - f); x.quadraticCurveTo(-35, 5, -10, 12); x.fill();
  x.beginPath(); x.moveTo(10, 0); x.quadraticCurveTo(40, -20 - f, 60, -5 - f); x.quadraticCurveTo(35, 5, 10, 12); x.fill();
  x.beginPath(); x.ellipse(0, 6, 16, 20, 0, 0, 7); x.fill();
  x.fillStyle = gold ? "#ffe9a8" : "#c9a68a"; x.beginPath(); x.ellipse(0, -20, 11, 13, 0, 0, 7); x.fill();
  x.fillStyle = "#000"; x.fillRect(-6, -23, 3, 3); x.fillRect(3, -23, 3, 3); x.fillRect(-3, -14, 6, 1.5);
  x.restore();
}
function drawDx(px, py, s = 1) {
  x.save(); x.translate(px, py); x.scale(s, s);
  const g = x.createRadialGradient(0, 0, 4, 0, 0, 50); g.addColorStop(0, "#fff3a0aa"); g.addColorStop(1, "#ffb30000");
  x.fillStyle = g; x.fillRect(-50, -50, 100, 100);
  x.fillStyle = "#ffc21a"; x.fillRect(-14, -5, 28, 34); x.beginPath(); x.arc(0, -16, 13, 0, 7); x.fill();
  x.strokeStyle = "#3a2500"; x.lineWidth = 2; x.strokeRect(-10, -20, 8, 5); x.strokeRect(2, -20, 8, 5);
  x.fillStyle = "#ffc21a"; x.save(); x.translate(14, 2); x.rotate(-1.1); x.fillRect(0, -3, 26, 6); x.restore();
  x.restore();
}

// ---------------- 1. Sobreviva à noite ----------------
export function noite() {
  stop();
  ui.innerHTML = `<p>Atravesse Naviraí até o amanhecer. <b>Fique embaixo das árvores</b> (círculos escuros), porque no aberto ele te vê. Recolha as 5 lanternas. Para se mover, arraste o dedo ou use as setas.</p>`;
  const p = { x: 40, y: H - 40 }, px = { x: W / 2, y: -60, vx: 0, vy: 0 }, keys = {};
  const trees = Array.from({ length: 11 }, () => ({ x: 60 + Math.random() * (W - 120), y: 60 + Math.random() * (H - 120), r: 28 + Math.random() * 22 }));
  const lights = Array.from({ length: 5 }, () => ({ x: 40 + Math.random() * (W - 80), y: 40 + Math.random() * (H - 80), got: false }));
  let target = null, t0 = performance.now(), expo = 0, over = false, got = 0;
  on(window, "keydown", e => keys[e.key] = 1); on(window, "keyup", e => keys[e.key] = 0);
  on(cv, "pointerdown", e => target = pt(e)); on(cv, "pointermove", e => { if (e.buttons) target = pt(e); }); on(cv, "pointerup", () => target = null);
  const step = () => {
    const t = (performance.now() - t0) / 1000, left = Math.max(0, 60 - t);
    let dx = (keys.ArrowRight || keys.d ? 1 : 0) - (keys.ArrowLeft || keys.a ? 1 : 0), dy = (keys.ArrowDown || keys.s ? 1 : 0) - (keys.ArrowUp || keys.w ? 1 : 0);
    if (target) { dx = target.x - p.x; dy = target.y - p.y; const d = Math.hypot(dx, dy); if (d < 4) dx = dy = 0; else { dx /= d; dy /= d; } }
    p.x = Math.max(10, Math.min(W - 10, p.x + dx * 2.6)); p.y = Math.max(10, Math.min(H - 10, p.y + dy * 2.6));
    const hidden = trees.some(tr => Math.hypot(tr.x - p.x, tr.y - p.y) < tr.r);
    expo = Math.max(0, Math.min(100, expo + (hidden ? -1.2 : .55)));
    const tx = hidden ? W / 2 + Math.cos(t) * 200 : p.x, ty = hidden ? 60 + Math.sin(t * 1.3) * 40 : p.y;
    const sp = hidden ? .03 : .012 + expo / 4000 + t / 9000;
    px.vx += (tx - px.x) * sp; px.vy += (ty - px.y) * sp; px.vx *= .9; px.vy *= .9; px.x += px.vx; px.y += px.vy;
    lights.forEach(l => { if (!l.got && Math.hypot(l.x - p.x, l.y - p.y) < 16) { l.got = true; got++; sfx("hit"); } });
    // desenho
    x.fillStyle = "#050806"; x.fillRect(0, 0, W, H);
    const sky = Math.min(1, t / 60); x.fillStyle = `rgba(90,60,120,${sky * .35})`; x.fillRect(0, 0, W, H);
    lights.forEach(l => { if (!l.got) { x.fillStyle = "#ffd76655"; x.beginPath(); x.arc(l.x, l.y, 14, 0, 7); x.fill(); x.fillStyle = "#ffd766"; x.fillRect(l.x - 3, l.y - 5, 6, 10); } });
    trees.forEach(tr => { x.fillStyle = "#0f2414"; x.beginPath(); x.arc(tr.x, tr.y, tr.r, 0, 7); x.fill(); });
    x.fillStyle = hidden ? "#4a7" : "#eee"; x.beginPath(); x.arc(p.x, p.y, 7, 0, 7); x.fill();
    drawPx(px.x, px.y, .8, t * 9);
    x.fillStyle = "#fff"; x.font = "15px monospace";
    x.fillText(`Amanhecer em ${left.toFixed(0)}s   Lanternas ${got}/5`, 12, 22);
    x.fillStyle = "#300"; x.fillRect(12, 32, 160, 8); x.fillStyle = "#d22"; x.fillRect(12, 32, expo * 1.6, 8);
    x.fillStyle = "#faa"; x.font = "11px monospace"; x.fillText("EXPOSIÇÃO", 178, 40);
    if (Math.hypot(px.x - p.x, px.y - p.y) < 22 && !hidden) { over = true; sfx("scare"); end(false, got, t); return; }
    if (left <= 0) { end(got >= 5, got, t); return; }
    loop = requestAnimationFrame(step);
  };
  const end = (win, g) => {
    x.fillStyle = "#000c"; x.fillRect(0, 0, W, H); x.fillStyle = win ? "#ffd766" : "#f44"; x.font = "28px Georgia"; x.textAlign = "center";
    x.fillText(win ? "Você viu o amanhecer." : !over ? `O sol nasceu… faltaram ${5 - g} lanternas.` : "Fiu fiu. Ele te achou.", W / 2, H / 2);
    x.font = "15px monospace"; x.fillStyle = "#ccc"; x.fillText("Toque para jogar de novo", W / 2, H / 2 + 34); x.textAlign = "left";
    on(cv, "click", noite);
  };
  loop = requestAnimationFrame(step);
}

// ---------------- 2. É por ali, confia ----------------
export function confia() {
  stop(); cv.style.display = "none";
  const situ = [
    ["Você está perdido na mata. Ouve um assobio à esquerda.", "⬅️ Por ali, confia.", ["Você acha a estrada! O Douradex brilha de orgulho.", "Era a origem do assobio. Você corre de volta."]],
    ["Duas trilhas: uma iluminada, outra escura.", "Pela escura, confia.", ["A escura tinha árvores. Ele não te viu.", "Tinha um córrego no caminho. Molhou tudo."]],
    ["Uma ponte velha balança no vento.", "Atravessa, confia.", ["A ponte segurou. Por pouco.", "A ponte não segurou. Mas o rio era raso."]],
    ["Uma casa com a luz acesa e a porta aberta.", "Entra, confia.", ["Uma senhora te dá café e abrigo.", "Não tinha ninguém. Só penas no chão."]],
    ["Uma sombra enorme passa pela lua.", "Olha pra cima, confia.", ["Era só uma nuvem. Ufa.", "Você olhou nos olhos dele."]],
    ["O Douradex aponta pro oeste, firme.", "Oeste. Sempre oeste. Confia.", ["Você chega em 1491. É uma longa história.", "Você anda em círculos até o amanhecer."]],
    ["Seu celular toca. É a voz da sua mãe pedindo pra sair.", "Atende e sai, confia.", ["Era mesmo sua mãe. Ela veio te buscar.", "Ele imita vozes. O comunicado avisou."]],
    ["Última encruzilhada antes da cidade.", "É por ali. Confia mesmo.", ["Você chega em casa. Fim.", "Você chega em casa. Mas qual casa?"]],
  ];
  let i = 0, vida = 3, pontos = 0;
  const render = () => {
    if (i >= situ.length || vida <= 0) {
      const b = best("px-confia", pontos);
      ui.innerHTML = `<div class="card"><h3>${vida > 0 ? "Você sobreviveu à noite." : "A noite te venceu."}</h3>Pontos: <b>${pontos}</b> · Recorde: ${b}<br><br><img src="img/douradex.jpg" style="max-width:160px"><p><i>"Eu disse que era por ali."</i> — Douradex</p><button class="btn" id="re">Jogar de novo</button></div>`;
      document.getElementById("re").onclick = confia; return;
    }
    const [s, d] = situ[i];
    ui.innerHTML = `<div class="card"><p class="sub">Situação ${i + 1}/${situ.length} · ❤️ ${"♥".repeat(vida)} · ${pontos} pts</p>
      <p style="font-size:1.1rem">${s}</p><p style="display:flex;gap:10px;align-items:center"><img src="img/douradex.jpg" style="width:60px;border-radius:50%"> <b style="color:#b8860b">Douradex:</b> <i>"${d}"</i></p>
      <button class="btn" id="sim" style="background:#b8860b">Confiar</button> <button class="btn red" id="nao">Não confiar</button><p id="res"></p></div>`;
    const go = (trust) => {
      const ok = Math.random() < (trust ? .55 : .5); const [good, bad] = situ[i][2];
      const txt = trust ? (ok ? good : bad) : (ok ? "Você foi pelo outro lado e deu certo." : "Você foi pelo outro lado. O Douradex fica magoado e o caminho era pior.");
      if (ok) { pontos += trust ? 15 : 10; sfx("chirp"); } else { vida--; sfx("hit"); }
      document.getElementById("res").innerHTML = `<b>${ok ? "✔" : "✘"}</b> ${txt}<br><button class="btn" id="nx">Continuar</button>`;
      document.getElementById("sim").disabled = document.getElementById("nao").disabled = true;
      document.getElementById("nx").onclick = () => { i++; render(); };
    };
    document.getElementById("sim").onclick = () => go(true); document.getElementById("nao").onclick = () => go(false);
  };
  render();
}

// ---------------- 3. Quiz do arquivo ----------------
export function quiz() {
  stop(); cv.style.display = "none";
  const Q = [
    ["Em que cidade aconteceu o Incidente 1367?", ["Naviraí (MS)", "Dourados (MS)", "Campo Grande (MS)", "Ponta Porã (MS)"], 0],
    ["Quantas vítimas foram atribuídas ao incidente?", ["13", "67", "1367", "41"], 1],
    ["O que o comunicado de emergência mandava evitar?", ["Rios", "Celulares", "Áreas abertas à noite", "Escolas"], 2],
    ["Qual é o bordão do Douradex?", ["Fiu fiu!", "É por ali, confia", "Não olhe pra cima", "Oeste sempre"], 1],
    ["Segundo a lenda cômica, em que ano o Fiu Fiu indicou terras a oeste?", ["1500", "1367", "1491", "1822"], 2],
    ["Qual som antecede uma aparição?", ["Bater de asas", "Um grito", "Assobio de duas notas", "Silêncio total"], 2],
    ["Onde o desenho em papel envelhecido foi achado?", ["Num poste", "Dentro de uma Bíblia", "No córrego", "Na prefeitura"], 1],
    ["Por que o Douradex é um péssimo guia pra fugir?", ["Ele é lento", "Ele brilha demais", "Ele dorme", "Ele assobia"], 1],
  ].sort(() => Math.random() - .5);
  let i = 0, ok = 0;
  const render = () => {
    if (i >= Q.length) { const b = best("px-quiz", ok); ui.innerHTML = `<div class="card"><h3>${ok}/${Q.length} acertos</h3>${ok === Q.length ? "Arquivista nível máximo. Ele já sabe seu nome." : ok > 4 ? "Bom conhecimento. Continue evitando áreas abertas." : "Volte para o <a href='index.html'>verbete principal</a>."}<br>Recorde: ${b}<br><br><button class="btn" id="re">Refazer</button></div>`; document.getElementById("re").onclick = quiz; return; }
    const [q, ops, c] = Q[i];
    ui.innerHTML = `<div class="card"><p class="sub">Pergunta ${i + 1}/${Q.length}</p><h3>${q}</h3>${ops.map((o, k) => `<p><button class="btn" style="width:100%;text-align:left;background:var(--box);color:var(--ink);border:1px solid var(--line)" data-k="${k}">${o}</button></p>`).join("")}</div>`;
    ui.querySelectorAll("[data-k]").forEach(b => b.onclick = () => {
      const k = +b.dataset.k; if (k === c) { ok++; sfx("chirp"); b.style.background = "#2a7a3a"; } else { sfx("hit"); b.style.background = "#a22"; ui.querySelector(`[data-k="${c}"]`).style.background = "#2a7a3a"; }
      ui.querySelectorAll("[data-k]").forEach(z => z.disabled = true); setTimeout(() => { i++; render(); }, 900);
    });
  };
  render();
}

// ---------------- 4. Tiro ao alvo (estilingue) ----------------
export function tiro() {
  stop();
  ui.innerHTML = `<p>Toque nos Passarex pra acertar a pedrinha. O <b style="color:#e8b923">Fiu Fiu dourado</b> vale 50. <b>Não acerte o Douradex!</b> Você tem 45 segundos.</p>`;
  let alvos = [], pts = 0, combo = 0, t0 = performance.now(), last = 0, shots = [], pops = [], mira = { x: W / 2, y: H / 2 };
  const spawn = (t) => {
    const r = Math.random(), dir = Math.random() < .5 ? 1 : -1;
    const tipo = r < .1 ? "dx" : r < .2 ? "fiu" : "px";
    alvos.push({ tipo, x: dir > 0 ? -60 : W + 60, y: 60 + Math.random() * (H - 200), vx: dir * (1.5 + Math.random() * 2 + t / 20) * (tipo === "fiu" ? 1.8 : 1), ph: Math.random() * 6, s: .7 + Math.random() * .5 });
  };
  on(cv, "pointermove", e => mira = pt(e));
  on(cv, "pointerdown", e => {
    const p = pt(e); mira = p; shots.push({ x: W / 2, y: H, tx: p.x, ty: p.y, k: 0 }); sfx("hit");
  });
  const step = (now) => {
    const t = (now - t0) / 1000, left = Math.max(0, 45 - t);
    if (now - last > Math.max(350, 1000 - t * 15)) { spawn(t); last = now; }
    // cenário
    const g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, "#0b1430"); g.addColorStop(1, "#24304a"); x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.fillStyle = "#e9e3c5"; x.beginPath(); x.arc(520, 80, 34, 0, 7); x.fill();
    x.fillStyle = "#0a160c"; for (let i = 0; i < 12; i++) { x.beginPath(); x.arc(i * 60, H - 30, 50 + (i % 3) * 12, 0, 7); x.fill(); }
    alvos.forEach(a => { a.x += a.vx; a.ph += .25; const yy = a.y + Math.sin(a.ph * .3) * 14;
      if (a.tipo === "dx") drawDx(a.x, yy, a.s * 1.2); else drawPx(a.x, yy, a.s, a.ph, a.tipo === "fiu"); a.yy = yy; });
    alvos = alvos.filter(a => a.x > -90 && a.x < W + 90 && !a.dead);
    shots.forEach(s => { s.k += .12; const k = Math.min(1, s.k), sx = W / 2 + (s.tx - W / 2) * k, sy = H + (s.ty - H) * k - Math.sin(k * Math.PI) * 60;
      x.fillStyle = "#bbb"; x.beginPath(); x.arc(sx, sy, 5 * (1.3 - k * .6), 0, 7); x.fill();
      if (s.k >= 1 && !s.done) { s.done = true; let hit = false;
        alvos.forEach(a => { if (!a.dead && Math.hypot(a.x - s.tx, a.yy - s.ty) < 38 * a.s) { a.dead = hit = true;
          const v = a.tipo === "dx" ? -40 : a.tipo === "fiu" ? 50 : 10 + combo * 2; pts += v; combo = a.tipo === "dx" ? 0 : combo + 1;
          pops.push({ x: a.x, y: a.yy, txt: a.tipo === "dx" ? "-40 ai! confia em mim!" : (v > 0 ? "+" : "") + v, a: 1, c: a.tipo === "dx" ? "#f55" : a.tipo === "fiu" ? "#ffd766" : "#fff" }); sfx(a.tipo === "dx" ? "scare" : "chirp"); } });
        if (!hit) combo = 0; } });
    shots = shots.filter(s => s.k < 1.1);
    pops.forEach(p => { p.y -= 1; p.a -= .02; x.globalAlpha = Math.max(0, p.a); x.fillStyle = p.c; x.font = "bold 18px monospace"; x.fillText(p.txt, p.x - 20, p.y); x.globalAlpha = 1; });
    pops = pops.filter(p => p.a > 0);
    // estilingue e mira
    x.strokeStyle = "#7a4a1f"; x.lineWidth = 8; x.beginPath(); x.moveTo(W / 2, H); x.lineTo(W / 2, H - 40); x.moveTo(W / 2, H - 40); x.lineTo(W / 2 - 22, H - 70); x.moveTo(W / 2, H - 40); x.lineTo(W / 2 + 22, H - 70); x.stroke();
    x.strokeStyle = "#f33"; x.lineWidth = 2; x.beginPath(); x.arc(mira.x, mira.y, 14, 0, 7); x.moveTo(mira.x - 20, mira.y); x.lineTo(mira.x + 20, mira.y); x.moveTo(mira.x, mira.y - 20); x.lineTo(mira.x, mira.y + 20); x.stroke();
    x.fillStyle = "#fff"; x.font = "16px monospace"; x.fillText(`Pontos ${pts}   Combo x${combo}   ${left.toFixed(0)}s`, 12, 24);
    if (left <= 0) {
      const b = best("px-tiro", pts);
      x.fillStyle = "#000c"; x.fillRect(0, 0, W, H); x.textAlign = "center"; x.fillStyle = "#ffd766"; x.font = "30px Georgia"; x.fillText(`${pts} pontos`, W / 2, H / 2 - 10);
      x.font = "15px monospace"; x.fillStyle = "#ccc"; x.fillText(`Recorde: ${b} · toque para jogar de novo`, W / 2, H / 2 + 24); x.textAlign = "left";
      setTimeout(() => on(cv, "click", tiro), 600); return;
    }
    loop = requestAnimationFrame(step);
  };
  loop = requestAnimationFrame(step);
}

const GAMES = { noite, confia, quiz, tiro };
document.querySelectorAll("[data-g]").forEach(b => b.onclick = () => {
  document.querySelectorAll("[data-g]").forEach(z => z.classList.remove("on")); b.classList.add("on"); GAMES[b.dataset.g]();
});
const start = location.hash.slice(1);
(document.querySelector(`[data-g="${start}"]`) || document.querySelector("[data-g]")).click();
