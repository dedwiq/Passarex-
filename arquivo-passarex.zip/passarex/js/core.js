// Núcleo do Arquivo Passarex: cabeçalho, menu, busca, tema, som e easter eggs.
export const CONFIG = {
  // Troque pelo seu usuário/repositório do GitHub (usado no botão "Envie seu relato")
  repo: "dedwig/Passarex-",
};

const PAGES = [
  ["index.html", "Página principal", "Passarex, entidade, ave, cabeça humana, início"],
  ["incidente.html", "Incidente 1367", "Naviraí, MS, comunicado, vítimas, emergência, áreas abertas"],
  ["personagens.html", "Personagens", "Passarex Fiu Fiu, Douradex, é por ali confia, 1491"],
  ["registros.html", "Registros e laboratório", "fotos noturnas, desenho, papel envelhecido, imagens, análise"],
  ["modelo3d.html", "Modelos 3D", "3D, Passarex, Douradex, estátua, interativo"],
  ["jogos.html", "Jogos", "sobreviva, noite, confia, quiz, tiro ao alvo, estilingue"],
  ["relatos.html", "Relatos", "testemunhas, envie, relato, avistamento"],
  ["sobre.html", "Sobre o arquivo", "ficção, creepypasta, aviso, créditos"],
];

const here = location.pathname.split("/").pop() || "index.html";

function header() {
  const h = document.createElement("header");
  h.className = "top";
  h.innerHTML = `
    <button id="menuBtn" class="tools" style="display:none;background:none;border:0;font-size:1.4rem;color:inherit">☰</button>
    <a class="logo" href="index.html">ARQUIVO <span>PASSAREX</span></a>
    <input id="q" type="search" placeholder="Pesquisar no arquivo" aria-label="Pesquisar">
    <div class="tools"><button id="snd" title="Som ambiente">🔇 som</button> <button id="thm" title="Tema">◐</button></div>
    <div id="results"></div>`;
  document.body.prepend(h);
}

function nav() {
  const n = document.createElement("nav");
  n.className = "side";
  n.innerHTML = `<h4>Navegação</h4>` +
    PAGES.map(([f, t]) => `<a href="${f}" class="${f === here ? "on" : ""}">${t}</a>`).join("") +
    `<h4>Ferramentas</h4><a href="#" id="rand">Registro aleatório</a><a href="relatos.html#enviar">Enviar relato</a>
     <h4>Estado</h4><div style="font-size:.8rem;color:var(--muted)">Nível de alerta:<br><b style="color:var(--red)">VERMELHO</b><br>Última atualização:<br><span id="clock"></span></div>`;
  const main = document.querySelector("main");
  const wrap = document.createElement("div");
  wrap.className = "wrap";
  main.before(wrap);
  wrap.append(n, main);
  document.getElementById("menuBtn").onclick = () => n.classList.toggle("open");
  document.getElementById("rand").onclick = (e) => {
    e.preventDefault();
    const p = PAGES[Math.floor(Math.random() * PAGES.length)][0];
    location.href = p;
  };
  const c = document.getElementById("clock");
  const tick = () => (c.textContent = new Date().toLocaleString("pt-BR"));
  tick(); setInterval(tick, 1000);
}

function footer() {
  const f = document.createElement("footer");
  f.innerHTML = `Obra de ficção. Qualquer semelhança com fatos reais é coincidência. · <a href="sobre.html">Sobre o arquivo</a><br>
  Este arquivo não foi verificado. Evite áreas abertas à noite.`;
  document.body.append(f);
}

function search() {
  const q = document.getElementById("q"), r = document.getElementById("results");
  q.oninput = () => {
    const v = q.value.trim().toLowerCase();
    if (!v) return (r.style.display = "none");
    if (v === "fiu fiu" || v === "douradex") toast(v === "douradex" ? "É por ali, confia. →" : "fiu fiu 🐦");
    const hits = PAGES.filter(([, t, k]) => (t + " " + k).toLowerCase().includes(v));
    r.innerHTML = hits.length ? hits.map(([f, t]) => `<a href="${f}">${t}</a>`).join("") :
      `<a>Nenhum resultado. <span class="redact">ele está ouvindo</span></a>`;
    r.style.display = "block";
  };
  q.onblur = () => setTimeout(() => (r.style.display = "none"), 200);
}

function theme() {
  const k = "px-theme";
  let t; try { t = localStorage.getItem(k); } catch {}
  if (t) document.documentElement.dataset.theme = t;
  document.getElementById("thm").onclick = () => {
    const n = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
    document.documentElement.dataset.theme = n;
    try { localStorage.setItem(k, n); } catch {}
  };
}

// ---------- Som ambiente sintetizado (vento + chiado + pio distante) ----------
let ctx, master, on = false, chirpTimer;
function noiseBuf(c) {
  const b = c.createBuffer(1, c.sampleRate * 2, c.sampleRate), d = b.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  return b;
}
export function sfx(type = "chirp") {
  if (!ctx) return;
  const t = ctx.currentTime, o = ctx.createOscillator(), g = ctx.createGain();
  o.connect(g); g.connect(master);
  if (type === "chirp") {
    o.type = "sine"; o.frequency.setValueAtTime(2400, t); o.frequency.exponentialRampToValueAtTime(1100, t + .25);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(.15, t + .03); g.gain.exponentialRampToValueAtTime(.001, t + .3);
    o.start(t); o.stop(t + .32);
  } else if (type === "hit") {
    o.type = "square"; o.frequency.setValueAtTime(300, t); o.frequency.exponentialRampToValueAtTime(60, t + .15);
    g.gain.setValueAtTime(.2, t); g.gain.exponentialRampToValueAtTime(.001, t + .18); o.start(t); o.stop(t + .2);
  } else if (type === "scare") {
    o.type = "sawtooth"; o.frequency.setValueAtTime(90, t); o.frequency.linearRampToValueAtTime(700, t + .6);
    g.gain.setValueAtTime(.25, t); g.gain.exponentialRampToValueAtTime(.001, t + .8); o.start(t); o.stop(t + .85);
  }
}
function startSound() {
  ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
  master = ctx.createGain(); master.gain.value = .6; master.connect(ctx.destination);
  const wind = ctx.createBufferSource(); wind.buffer = noiseBuf(ctx); wind.loop = true;
  const lp = ctx.createBiquadFilter(); lp.type = "lowpass"; lp.frequency.value = 400;
  const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = .08; lg.gain.value = 250;
  lfo.connect(lg); lg.connect(lp.frequency); lfo.start();
  const wg = ctx.createGain(); wg.gain.value = .25;
  wind.connect(lp); lp.connect(wg); wg.connect(master); wind.start();
  const st = ctx.createBufferSource(); st.buffer = noiseBuf(ctx); st.loop = true;
  const hp = ctx.createBiquadFilter(); hp.type = "highpass"; hp.frequency.value = 3000;
  const sg = ctx.createGain(); sg.gain.value = .02;
  st.connect(hp); hp.connect(sg); sg.connect(master); st.start();
  const loop = () => { sfx("chirp"); setTimeout(() => sfx("chirp"), 180); chirpTimer = setTimeout(loop, 9000 + Math.random() * 14000); };
  chirpTimer = setTimeout(loop, 4000);
}
function sound() {
  const b = document.getElementById("snd");
  b.onclick = () => {
    on = !on;
    if (on) { if (!master) startSound(); else master.gain.value = .6; ctx.resume(); b.textContent = "🔊 som"; }
    else { master.gain.value = 0; b.textContent = "🔇 som"; }
  };
}

export function toast(msg, ms = 2500) {
  const t = document.createElement("div"); t.className = "toast"; t.textContent = msg;
  document.body.append(t); setTimeout(() => t.remove(), ms);
}

function eggs() {
  // Código secreto: digitar "fiufiu" em qualquer página
  let buf = "";
  addEventListener("keydown", (e) => {
    buf = (buf + e.key.toLowerCase()).slice(-6);
    if (buf === "fiufiu") { document.body.classList.toggle("scan"); document.querySelector("main").classList.toggle("corrupt"); toast("ARQUIVO CORROMPIDO // fiu fiu"); sfx("scare"); }
  });
  // Às vezes, à noite, o título pisca
  const h = new Date().getHours();
  if ((h >= 22 || h < 5) && Math.random() < .4) document.querySelector("h1")?.classList.add("glitch");
}

header(); nav(); footer(); search(); theme(); sound(); eggs();
