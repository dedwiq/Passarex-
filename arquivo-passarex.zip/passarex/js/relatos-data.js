// Relatos publicados. Para aprovar um relato enviado pelo GitHub, copie-o para esta lista.
export default [
  { nome: "M. A., 54 anos", local: "Zona rural de Naviraí", data: "Dia 2", texto: "Eu tava fechando o galinheiro quando ouvi o assobio. Duas notas, igualzinho meu falecido pai chamava a gente. Olhei pra cerca e tinha um bicho maior que um bezerro, mas com cara de gente. Calmo. Sorrindo de leve. Entrei e não saí mais de noite." },
  { nome: "Anônimo", local: "Centro", data: "Dia 14", texto: "Doze pessoas no ponto de ônibus ouviram ao mesmo tempo, e cada uma jura que veio de um lado diferente. Eu ouvi vindo de cima." },
  { nome: "Professora R.", local: "Escola municipal", data: "Dia 10", texto: "A gente fez a coleta de água no córrego pra aula de ciências, ainda de dia. Na amostra veio uma pena de quase meio metro. Os alunos acharam engraçado. Eu não achei." },
  { nome: "Vigia noturno", local: "Rua 7", data: "Dia 9", texto: "A câmera 3 apagou às 02h13. Antes de apagar, a imagem mostrou um rosto bem perto da lente. Não era de nenhum funcionário. O arquivo sumiu do sistema no dia seguinte." },
  { nome: "Usuário @fiufiu_real", local: "Internet", data: "—", texto: "gente o passarex fiu fiu passou aqui na rua e me indicou o caminho da padaria. o amigo dourado dele falou 'é por ali, confia'. não era por ali. ⭐⭐⭐⭐⭐" },
  { nome: "J. P.", local: "Saída para Itaquiraí", data: "Dia 21", texto: "Última noite. O assobio parou de repente, no meio da segunda nota. O silêncio foi pior que o barulho. Até hoje eu deixo a luz da varanda acesa." },
];
