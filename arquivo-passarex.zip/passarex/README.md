# Arquivo Passarex

Site estático (HTML/CSS/JS puro), pronto para o GitHub Pages.

## Publicar
1. Suba todos os arquivos desta pasta para a raiz do repositório (ou para a pasta `docs/`).
2. No GitHub, vá em **Settings → Pages → Source: Deploy from a branch**, escolha a branch e a pasta, e salve.
3. Em 1 ou 2 minutos o site aparece em `https://SEU-USUARIO.github.io/NOME-DO-REPO/`.

## Personalizar
- **Repositório dos relatos:** edite `CONFIG.repo` em `js/core.js`.
- **Aprovar relatos:** copie o texto da issue para `js/relatos-data.js`.
- **Imagens originais:** troque `img/passarex-desenho.svg` pelo seu desenho (mantenha o nome ou ajuste os `src`).
- **Modelos 3D próprios:** coloque `models/passarex.glb` e/ou `models/douradex.glb`. A página 3D carrega os arquivos sozinha.

## Segredo
Digite `fiufiu` em qualquer página.
